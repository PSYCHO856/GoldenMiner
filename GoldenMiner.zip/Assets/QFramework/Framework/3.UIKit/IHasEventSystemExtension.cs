using System;

namespace QFramework.Framework._3.UIKit
{
    public static class IHasEventSystemExtension
    {

    }
}