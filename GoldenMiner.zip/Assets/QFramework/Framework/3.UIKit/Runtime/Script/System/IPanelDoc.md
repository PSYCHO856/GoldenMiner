作者：SilenceT     邮箱：499683507@qq.com

# IPanel

# 接口

# 描述

**UPanel** 自身资源管理脚本的基础接口


# **属性**

|                       |                   |
| --------------------- | ----------------- |
| Transform Transform   | 该组件Transform值 |
| UIPanelInfo PanelInfo | UIPanel界面信息   |



# **方法**

|           |            |
| --------- | ---------- |
| **Init**  | 初始化界面 |
| **Open**  | 打开界面   |
| **Show**  | 显示界面   |
| **Hide**  | 隐藏界面   |
| **Close** | 关闭界面   |

