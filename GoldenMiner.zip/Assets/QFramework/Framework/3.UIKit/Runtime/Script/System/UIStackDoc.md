作者：SilenceT     邮箱：499683507@qq.com
# UIPanelInfo

# 描述

UIPanel信息类

# **属性**

|                        |                   |
| ---------------------- | ----------------- |
| IUIData UIData         | UI传递数据对象    |
| UILevel Level          | UI等级            |
| String AssetBundleName | AssetBundle名称   |
| String PanelName       | UIPanel预制体名称 |
