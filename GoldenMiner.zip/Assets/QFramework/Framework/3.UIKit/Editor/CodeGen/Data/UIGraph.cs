using QFramework.CodeGen;

namespace QFramework
{
    public class UIGraph : IGraphConfiguration
    {
        public string CodeOutputPath { get; private set; }
    }
}