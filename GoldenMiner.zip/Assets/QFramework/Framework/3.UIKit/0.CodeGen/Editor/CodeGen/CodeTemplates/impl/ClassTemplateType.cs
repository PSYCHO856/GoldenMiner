namespace QFramework.CodeGen
{
    public enum ClassTemplateType
    {
        BaseClass,
        Copy,
    }
}