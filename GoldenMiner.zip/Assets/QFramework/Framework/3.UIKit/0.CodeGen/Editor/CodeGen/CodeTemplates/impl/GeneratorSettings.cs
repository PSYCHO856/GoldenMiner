using System;
using UnityEngine;

namespace QFramework.CodeGen
{
    public class GeneratorSettings
    {

    }
}