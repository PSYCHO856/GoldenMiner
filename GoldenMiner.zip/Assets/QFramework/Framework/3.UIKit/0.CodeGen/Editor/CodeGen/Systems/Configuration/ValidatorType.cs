namespace QFramework.CodeGen
{
    public enum ValidatorType
    {
        Error
    }
}