using System;

namespace QFramework.CodeGen.Pro
{
    public class TemplateMember : Attribute
    {
        public string Group { get; set; }

    }
}