namespace Invert.Data
{
    public interface IValueItem
    {
        string Identifier { get; set; }
    }
}