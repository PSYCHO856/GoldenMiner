namespace QFramework.CodeGen
{
    public enum ConnectorSide
    {
        Left,
        Right,
    }
}