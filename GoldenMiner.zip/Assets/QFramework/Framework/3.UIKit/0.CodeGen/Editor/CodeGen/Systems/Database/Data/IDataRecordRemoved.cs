namespace Invert.Data
{
    public interface IDataRecordRemoved
    {
        
    }
}