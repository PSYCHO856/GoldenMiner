namespace QFramework.CodeGen
{
    public interface IDebugLogger
    {
        void Log(string message);
    }
}