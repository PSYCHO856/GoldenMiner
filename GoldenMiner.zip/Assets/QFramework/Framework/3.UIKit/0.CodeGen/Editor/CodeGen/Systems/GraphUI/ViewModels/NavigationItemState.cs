namespace QFramework.CodeGen
{
    public enum NavigationItemState
    {
        Regular,
        Current,
    }
}