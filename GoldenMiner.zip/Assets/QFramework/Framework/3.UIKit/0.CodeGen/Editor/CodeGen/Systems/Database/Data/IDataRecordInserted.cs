namespace Invert.Data
{
    public interface IDataRecordInserted
    {
    }
}