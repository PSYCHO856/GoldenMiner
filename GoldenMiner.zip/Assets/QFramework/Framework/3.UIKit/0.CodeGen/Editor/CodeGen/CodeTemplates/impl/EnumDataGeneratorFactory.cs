using System.Collections.Generic;

namespace QFramework.CodeGen
{
    //public class EnumDataGeneratorFactory : DesignerGeneratorFactory<EnumData>
    //{
    //    public override IEnumerable<OutputGenerator> CreateGenerators(GeneratorSettings settings, ICodePathStrategy pathStrategy, INodeRepository diagramData, EnumData item)
    //    {
    //        yield return new EnumCodeGenerator()
    //        {
    //            EnumData = item,
    //            Filename = pathStrategy.GetEditableFilePath(item),
    //        };

    //    }
    //}
}