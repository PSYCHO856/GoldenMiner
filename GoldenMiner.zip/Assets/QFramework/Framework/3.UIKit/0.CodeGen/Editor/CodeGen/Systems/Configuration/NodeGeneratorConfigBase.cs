using System.Collections.Generic;

namespace QFramework.CodeGen
{
    public class NodeGeneratorConfigBase
    {

    }
}