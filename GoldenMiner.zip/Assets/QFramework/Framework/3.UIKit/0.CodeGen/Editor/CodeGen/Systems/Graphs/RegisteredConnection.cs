using System;

namespace QFramework.CodeGen
{
    public class RegisteredConnection
    {
        public Type TOutputType { get; set; }
        public Type TInputType { get; set; }
    }
}