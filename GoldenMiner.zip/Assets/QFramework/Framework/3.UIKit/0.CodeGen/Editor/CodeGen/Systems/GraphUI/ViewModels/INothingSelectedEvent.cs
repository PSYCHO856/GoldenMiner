namespace QFramework.CodeGen
{
    public interface INothingSelectedEvent
    {
        void NothingSelected();
    }
}