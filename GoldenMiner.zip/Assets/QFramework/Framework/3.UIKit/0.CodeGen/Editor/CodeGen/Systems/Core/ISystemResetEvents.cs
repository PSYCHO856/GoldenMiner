namespace QFramework.CodeGen
{
    public interface ISystemResetEvents
    {
        void SystemResetting();
        void SystemRestarted();
    }
}