using System;

namespace QFramework.CodeGen
{
    public class TemplateComplete : Attribute
    {

    }
}