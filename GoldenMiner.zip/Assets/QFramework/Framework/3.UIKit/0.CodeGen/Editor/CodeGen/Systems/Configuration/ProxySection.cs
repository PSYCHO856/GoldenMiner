namespace QFramework.CodeGen
{
    public class ProxySection : Section
    {
        public ProxySection(string name, SectionVisibility visibility) : base(name, visibility)
        {
        }
    }
}