﻿namespace QFramework.CodeGen.Pro
{
    public interface ITemplate
    {

    }
}