namespace QFramework.CodeGen
{
    public interface IItem
    {
    }
}