namespace QFramework.CodeGen
{
    public interface IOnDemandTemplate : IClassTemplate
    {
        
    }
}