using System;

namespace QFramework.CodeGen
{
    public class TemplateSetup : Attribute
    {

    }
}