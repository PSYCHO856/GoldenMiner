namespace QFramework.CodeGen
{
    public interface IClassTypeNode : IDiagramNodeItem
    {
        string ClassName { get; }
    }
}