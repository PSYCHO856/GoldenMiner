namespace QFramework.CodeGen
{
    public class _TEMPLATETYPE_
    {

        public virtual string TheType(TemplateContext context)
        {
            return "void";
        }
    }
}