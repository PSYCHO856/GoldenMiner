namespace QFramework.CodeGen
{
    public interface IGraphLoaded
    {
        void GraphLoaded();
    }
}