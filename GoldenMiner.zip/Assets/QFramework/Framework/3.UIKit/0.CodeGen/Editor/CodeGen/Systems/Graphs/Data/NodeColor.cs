namespace QFramework.CodeGen
{
    public enum NodeColor
    {
        Gray,
        DarkGray,
        Blue,
        LightGray,
        Black,
        DarkDarkGray,
        Orange,
        Red,
        Yellow,
        Green,
        Purple,
        Pink,
        YellowGreen,

    }
}