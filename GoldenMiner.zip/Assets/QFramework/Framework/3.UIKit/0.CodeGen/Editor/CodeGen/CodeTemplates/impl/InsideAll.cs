namespace QFramework.CodeGen
{
    public class InsideAll : Inside
    {
        public InsideAll() : base(TemplateLocation.Both)
        {
        }
    }
}