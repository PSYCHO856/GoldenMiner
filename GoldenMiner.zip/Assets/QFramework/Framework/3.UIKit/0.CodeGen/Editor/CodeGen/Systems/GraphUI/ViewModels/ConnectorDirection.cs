namespace QFramework.CodeGen
{
    public enum ConnectorDirection
    {
        Input,
        Output,
    }
}