namespace QFramework.CodeGen
{
    public class WithName : WithNameFormat
    {
        public WithName() : base("{0}")
        {
        }
    }
}