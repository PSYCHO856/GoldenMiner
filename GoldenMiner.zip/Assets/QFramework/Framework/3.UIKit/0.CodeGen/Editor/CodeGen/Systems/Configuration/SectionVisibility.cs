namespace QFramework.CodeGen
{
    public enum SectionVisibility
    {
        Always,
        WhenNodeIsFilter,
    }
}