namespace QFramework.CodeGen
{
    public interface ITemplateCustomFilename
    {
        string Filename { get; }
    }
}