namespace QFramework.CodeGen
{
    public interface IGraphConfiguration : IItem
    {
        string CodeOutputPath { get;  }
    }
}