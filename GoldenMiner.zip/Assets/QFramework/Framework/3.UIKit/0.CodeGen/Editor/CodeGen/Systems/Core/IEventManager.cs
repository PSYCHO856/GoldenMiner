namespace QFramework.CodeGen
{
    public interface IEventManager
    {
    }
}