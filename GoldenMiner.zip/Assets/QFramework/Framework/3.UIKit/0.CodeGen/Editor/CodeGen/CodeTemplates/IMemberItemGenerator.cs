namespace QFramework.CodeGen
{
    //public interface IMemberItemGenerator : IMemberGenerator
    //{
    //    object ItemObject { get; set; }
        
    //}
}