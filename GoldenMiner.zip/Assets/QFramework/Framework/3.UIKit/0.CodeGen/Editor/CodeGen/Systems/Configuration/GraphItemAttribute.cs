using System;

namespace QFramework.CodeGen
{
    public class GraphItemAttribute : Attribute
    {
        public int OrderIndex { get; set; }
    }
}