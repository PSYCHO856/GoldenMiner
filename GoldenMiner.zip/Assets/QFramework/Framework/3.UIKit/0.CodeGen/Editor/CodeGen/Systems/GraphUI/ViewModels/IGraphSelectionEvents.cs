namespace QFramework.CodeGen
{
    public interface IGraphSelectionEvents
    {
        void SelectionChanged(GraphItemViewModel selected);
    }
}