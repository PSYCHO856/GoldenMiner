namespace QFramework.CodeGen
{
    public class ViewModel 
    {
    }
}