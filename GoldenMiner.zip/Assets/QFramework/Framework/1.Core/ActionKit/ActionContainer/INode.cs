namespace QFramework
{
    public interface INode
    {
        IAction CurrentExecutingNode { get; }
    }
}