namespace QFramework
{
    public interface IFrameworkCommand : ICommand
    {
        
    }
}