﻿// using UnityEngine;
//
// namespace QFramework
// {
// 	// public class QFrameworkBehaviour : MonoBehaviour
// 	// {
// 	// 	/// <summary>
// 	// 	/// 默认都统一归 IFramework 管理
// 	// 	/// </summary>
// 	// 	public virtual IManager Manager
// 	// 	{
// 	// 		get { return Framework.GetModule<IFramework>(); }
// 	// 	}
// 	// }
// }