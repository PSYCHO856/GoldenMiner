﻿namespace QFramework.PackageKit.Query
{
    public class SearchQuery : IQuery
    {
        
    }
}