﻿namespace QFramework.PackageKit.Command
{
    public interface IPackageManagerCommand : ICommand
    {
        
    }
}