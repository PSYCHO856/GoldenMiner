﻿namespace QFramework.PackageKit
{
    public class PackageMakerApp : AbstractApp<IPackageMakerCommand>
    {
        protected override void ConfigureService(IQFrameworkContainer container)
        {
            
        }
    }
}