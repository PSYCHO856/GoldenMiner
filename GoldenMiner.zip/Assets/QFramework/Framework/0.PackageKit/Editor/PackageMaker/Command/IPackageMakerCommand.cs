﻿namespace QFramework.PackageKit
{
    public interface IPackageMakerCommand : ICommand
    {
        
    }
}