namespace QFramework.PackageKit
{
    public interface IPackageLoginCommand : ICommand
    {
    }
}