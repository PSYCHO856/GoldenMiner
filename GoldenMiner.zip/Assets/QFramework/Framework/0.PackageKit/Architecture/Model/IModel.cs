namespace QFramework
{
    public interface IModel
    {
        
    }
}