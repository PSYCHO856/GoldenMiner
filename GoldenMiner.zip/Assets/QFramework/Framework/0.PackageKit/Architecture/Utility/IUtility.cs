namespace QFramework
{
    public interface IUtility
    {
        
    }
}