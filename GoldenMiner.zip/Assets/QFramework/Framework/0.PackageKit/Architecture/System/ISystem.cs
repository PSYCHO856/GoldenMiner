namespace QFramework
{
    public interface ISystem
    {
        
    }
}