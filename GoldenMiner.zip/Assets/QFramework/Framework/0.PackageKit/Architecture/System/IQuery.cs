﻿namespace QFramework
{
    public interface IQuery
    {
        
    }
}